﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InfoAboutCountry
{
    public partial class mainForm : Form
    {

        public mainForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Data_Base_mdbDataSet.Страны". При необходимости она может быть перемещена или удалена.
            this.страныTableAdapter.Fill(this._Data_Base_mdbDataSet.Страны);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Data_Base_mdbDataSet.Города". При необходимости она может быть перемещена или удалена.
            this.городаTableAdapter.Fill(this._Data_Base_mdbDataSet.Города);

        }

        private void сохранитьИзмененияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            страныTableAdapter.Update(_Data_Base_mdbDataSet);
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView2.DataSource = _Data_Base_mdbDataSet.Страны;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView2.DataSource = null;
        }
    }
}
